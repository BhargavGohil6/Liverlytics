import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Alert,
  ActivityIndicator,
} from 'react-native';
import ToggleSwitch from 'toggle-switch-react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import Icon2 from 'react-native-vector-icons/Feather';
import Icon3 from 'react-native-vector-icons/FontAwesome5';
import { useDispatch } from 'react-redux';
import { setHealthAccess } from './slices/onboardingSlice';
import responsive from '../../theme/responsive';
import { Navyblue, BlueishGray, PRIMARY_COLOR, CoolGray } from '../../theme/color';

// ---------- TYPES ----------
type HealthAccessData = {
  steps: number;
  heart_rate: number;
  sleep: number;
  weight: number;
  blood_pressure: number;
  spo2: number;
};

// ---------- COMPONENT ----------
const HealthAccess = () => {
const dispatch = useDispatch();
  // Local toggle states (1 = enabled, 0 = disabled)
  const [toggles, setToggles] = useState<HealthAccessData>({
    steps: 1,
    heart_rate: 1,
    sleep: 1,
    weight: 1,
    blood_pressure: 1,
    spo2: 1,
  });

  const [loading, setLoading] = useState(false);


  // Generic toggle handler
 const handleToggle = (key: keyof HealthAccessData) => {
  const newValue = toggles[key] === 1 ? 0 : 1;
  const updated = { ...toggles, [key]: newValue };
  setToggles(updated);
  dispatch(setHealthAccess(updated)); // ← Ye line add kar do
};

  if (loading && Object.values(toggles).every(v => v === 1)) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={PRIMARY_COLOR} />
      </View>
    );
  }

  return (
    <ScrollView >
      <Text style={styles.heading}>Allow Health Data Access</Text>
      <Text style={styles.description}>
        We use your health data to personalize your trends and alerts. Access is
        read-only and never modifies your data.
      </Text>

      {/* Steps */}
      <PermissionRow
        icon={<Icon name="footsteps-outline" size={30} color={Navyblue} />}
        title="Steps"
        subtitle="Daily step count to estimate activity levels."
        required
        isOn={toggles.steps === 1}
        onToggle={() => handleToggle('steps')}
        disabled={loading}
      />

      {/* Heart Rate */}
      <PermissionRow
        icon={<Icon2 name="heart" size={30} color={Navyblue} />}
        title="Heart Rate + Resting HR"
        subtitle="Heart rate patterns to surface early risk signals."
        required
        isOn={toggles.heart_rate === 1}
        onToggle={() => handleToggle('heart_rate')}
        disabled={loading}
      />

      {/* Sleep */}
      <PermissionRow
        icon={<Icon2 name="moon" size={30} color={Navyblue} />}
        title="Sleep Duration"
        subtitle="Total sleep time to inform recovery insights."
        required
        isOn={toggles.sleep === 1}
        onToggle={() => handleToggle('sleep')}
        disabled={loading}
      />

      {/* Weight */}
      <PermissionRow
        icon={<Icon3 name="weight-hanging" size={30} color={Navyblue} />}
        title="Weight"
        subtitle="Body weight to track changes over time."
        required
        isOn={toggles.weight === 1}
        onToggle={() => handleToggle('weight')}
        disabled={loading}
      />

      {/* Blood Pressure */}
      <PermissionRow
        icon={<Icon2 name="activity" size={30} color={Navyblue} />}
        title="Blood Pressure"
        subtitle="Systolic/diastolic readings to enrich risk models."
        isOn={toggles.blood_pressure === 0}
        onToggle={() => handleToggle('blood_pressure')}
        disabled={loading}
      />

      {/* SpO2 */}
      <PermissionRow
        icon={<Icon2 name="cloud-drizzle" size={30} color={Navyblue} />}
        title="SpO₂ (Oxygen Saturation)"
        subtitle="Oxygen saturation to monitor cardiorespiratory status."
        isOn={toggles.spo2 === 0}
        onToggle={() => handleToggle('spo2')}
        disabled={loading}
      />
    </ScrollView>
  );
};

// -----------------------------------------------------------------
// Reusable row component (cleaner code)
// -----------------------------------------------------------------
type PermissionRowProps = {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  required?: boolean;
  isOn: boolean;
  onToggle: () => void;
  disabled?: boolean;
};

const PermissionRow = ({
  icon,
  title,
  subtitle,
  required = false,
  isOn,
  onToggle,
  disabled,
}: PermissionRowProps) => {
  const isToggleDisabled = required || disabled;
  return(
  <View style={styles.container}>
    {icon}
    <View style={{ flex: 1, marginLeft: responsive.margin(15) }}>
      <Text style={styles.title}>
        {title}{' '}
        {required && <Text style={styles.requiredTag}>Required</Text>}
      </Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </View>

    <ToggleSwitch
      isOn={required ? true : isOn}
      onColor={PRIMARY_COLOR}
      offColor="#ccc"
      size="medium"
      disabled={isToggleDisabled}
     onToggle={required ? () => {} : onToggle}
    />
  </View>
  )
};

export default HealthAccess;

// -----------------------------------------------------------------
// Styles
// -----------------------------------------------------------------
const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: responsive.padding(10),
    borderRadius: responsive.borderRadius(12),
    borderWidth: 1,
    borderColor: CoolGray,
    marginVertical: responsive.margin(8),
  },
  heading: {
    fontSize: responsive.fontSize(24),
    fontWeight: '700',
    color: Navyblue,
    marginBottom: responsive.margin(10),
  },
  description: {
    fontSize: responsive.fontSize(14),
    color: BlueishGray,
    marginBottom: responsive.margin(25),
    lineHeight: 20,
  },
  title: {
    fontSize: responsive.fontSize(16),
    fontWeight: '600',
    color: Navyblue,
  },
  subtitle: {
    fontSize: responsive.fontSize(13),
    color: BlueishGray,
    marginTop: 4,
  },
  requiredTag: {
    fontSize: responsive.fontSize(11),
    color: PRIMARY_COLOR,
    borderWidth: 1,
    borderColor: PRIMARY_COLOR,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
});