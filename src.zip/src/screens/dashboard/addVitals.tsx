import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
} from 'react-native';

// Note: Install react-native-vector-icons or use expo icons
// npm install react-native-vector-icons
import Icon from 'react-native-vector-icons/Feather';

export default function AddVitalsScreen() {
  const [heartRate, setHeartRate] = useState('');
  const [restingHR, setRestingHR] = useState('');
  const [steps, setSteps] = useState('');
  const [sleepMinutes, setSleepMinutes] = useState('');
  const [spo2, setSpo2] = useState('');
  const [weight, setWeight] = useState('');
  const [weightUnit, setWeightUnit] = useState('kg');
  const [systolic, setSystolic] = useState('');
  const [diastolic, setDiastolic] = useState('');
  const [showUnitPicker, setShowUnitPicker] = useState(false);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton}>
          <Icon name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        
        <View style={styles.logoContainer}>
          <View style={styles.logo}>
            <Icon name="trending-up" size={20} color="#fff" />
          </View>
          <Text style={styles.logoText}>Liverlytics</Text>
        </View>
        
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.todayButton}>
            <Text style={styles.todayText}>Today</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.bellIcon}>
            <Icon name="bell" size={22} color="#333" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Title Section */}
        <View style={styles.titleSection}>
          <Text style={styles.title}>Add Vitals</Text>
          <Text style={styles.subtitle}>
            Enter today's readings or update wearable data.
          </Text>
        </View>

        {/* Heart Rate */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Heart Rate</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={heartRate}
              onChangeText={setHeartRate}
            />
            <Text style={styles.unit}>bpm</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="info" size={16} color="#666" />
            <Text style={styles.infoText}>
              Resting HR auto-imported when available.
            </Text>
          </View>
        </View>

        {/* Resting Heart Rate */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Resting Heart Rate</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={restingHR}
              onChangeText={setRestingHR}
            />
            <Text style={styles.unit}>bpm</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="watch" size={16} color="#666" />
            <Text style={styles.infoText}>
              Tracked via wearable when connected.
            </Text>
          </View>
        </View>

        {/* Steps */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Steps</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={steps}
              onChangeText={setSteps}
            />
            <Text style={styles.unit}>steps</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="smartphone" size={16} color="#666" />
            <Text style={styles.infoText}>
              Imported from smartwatch when available.
            </Text>
          </View>
        </View>

        {/* Sleep Minutes */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Sleep Minutes</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={sleepMinutes}
              onChangeText={setSleepMinutes}
            />
            <Text style={styles.unit}>min</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="moon" size={16} color="#666" />
            <Text style={styles.infoText}>
              Total sleep duration from last night.
            </Text>
          </View>
        </View>

        {/* SpO2 */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>SpO₂</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={spo2}
              onChangeText={setSpo2}
            />
            <Text style={styles.unit}>%</Text>
          </View>
          <View style={styles.infoRow}>
            <Icon name="activity" size={16} color="#666" />
            <Text style={styles.infoText}>
              Optional but helpful for flagging low oxygen.
            </Text>
          </View>
        </View>

        {/* Weight */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Weight</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Tap to enter"
              placeholderTextColor="#999"
              keyboardType="numeric"
              value={weight}
              onChangeText={setWeight}
            />
            <TouchableOpacity 
              style={styles.unitSelector}
              onPress={() => setShowUnitPicker(!showUnitPicker)}
            >
              <Text style={styles.unitSelectorText}>
                select{'\n'}option
              </Text>
              <Icon name="chevron-down" size={16} color="#666" />
            </TouchableOpacity>
          </View>
          
          {showUnitPicker && (
            <View style={styles.unitPicker}>
              <TouchableOpacity 
                style={[styles.unitOption, weightUnit === 'kg' && styles.unitOptionActive]}
                onPress={() => {
                  setWeightUnit('kg');
                  setShowUnitPicker(false);
                }}
              >
                <Text style={[styles.unitOptionText, weightUnit === 'kg' && styles.unitOptionTextActive]}>
                  kg
                </Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.unitOption, weightUnit === 'lb' && styles.unitOptionActive]}
                onPress={() => {
                  setWeightUnit('lb');
                  setShowUnitPicker(false);
                }}
              >
                <Text style={[styles.unitOptionText, weightUnit === 'lb' && styles.unitOptionTextActive]}>
                  lb
                </Text>
              </TouchableOpacity>
            </View>
          )}
          
          <View style={styles.infoRow}>
            <Icon name="droplet" size={16} color="#666" />
            <Text style={styles.infoText}>
              Tracks rapid fluid retention changes.
            </Text>
          </View>
        </View>

        {/* Blood Pressure */}
        <View style={styles.inputCard}>
          <Text style={styles.label}>Blood Pressure (Optional)</Text>
          <View style={styles.bpContainer}>
            <View style={styles.bpInput}>
              <TextInput
                style={styles.bpTextInput}
                placeholder="Systolic"
                placeholderTextColor="#999"
                keyboardType="numeric"
                value={systolic}
                onChangeText={setSystolic}
              />
              <Text style={styles.bpUnit}>mmHg</Text>
            </View>
            <View style={styles.bpInput}>
              <TextInput
                style={styles.bpTextInput}
                placeholder="Diastolic"
                placeholderTextColor="#999"
                keyboardType="numeric"
                value={diastolic}
                onChangeText={setDiastolic}
              />
              <Text style={styles.bpUnit}>mmHg</Text>
            </View>
          </View>
          <View style={styles.infoRow}>
            <Icon name="heart" size={16} color="#666" />
            <Text style={styles.infoText}>
              Optional if you track BP.
            </Text>
          </View>
        </View>

        {/* AI Trend Check Info */}
        <View style={styles.aiInfoCard}>
          <Text style={styles.aiInfoTitle}>AI Trend Check (On-Device)</Text>
          <Text style={styles.aiInfoText}>
            Your entries will be analyzed for unusual changes.{'\n'}
            Cloud-based analytics only used if you opted in.
          </Text>
        </View>

        {/* Save Button */}
        <TouchableOpacity style={styles.saveButton}>
          <Text style={styles.saveButtonText}>Save Vitals</Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  backButton: {
    padding: 4,
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    position: 'absolute',
    left: 0,
    right: 0,
    justifyContent: 'center',
    zIndex: -1,
  },
  logo: {
    width: 32,
    height: 32,
    borderRadius: 6,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  logoText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1a1a1a',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  todayButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#F5F5F5',
    borderRadius: 6,
  },
  todayText: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  bellIcon: {
    padding: 4,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 16,
  },
  titleSection: {
    paddingTop: 24,
    paddingBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  inputCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1a1a1a',
    marginBottom: 12,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  unit: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: '#666',
    lineHeight: 18,
  },
  unitSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingLeft: 12,
    borderLeftWidth: 1,
    borderLeftColor: '#E0E0E0',
  },
  unitSelectorText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    lineHeight: 14,
  },
  unitPicker: {
    flexDirection: 'row',
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    padding: 4,
    marginBottom: 12,
  },
  unitOption: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  unitOptionActive: {
    backgroundColor: '#fff',
  },
  unitOptionText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  unitOptionTextActive: {
    color: '#333',
    fontWeight: '600',
  },
  bpContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  bpInput: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  bpTextInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  bpUnit: {
    fontSize: 12,
    color: '#666',
    marginLeft: 8,
  },
  aiInfoCard: {
    backgroundColor: '#00695C',
    borderRadius: 12,
    padding: 16,
    marginTop: 8,
    marginBottom: 20,
  },
  aiInfoTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 8,
  },
  aiInfoText: {
    fontSize: 13,
    color: '#E0F2F1',
    lineHeight: 19,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
});