import React from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet,
  SafeAreaView,
  StatusBar
} from 'react-native';
import { 
  Activity, 
  Plus, 
  TestTube, 
  Utensils, 
  FileText, 
  Flag, 
  Heart, 
  Scale, 
  Droplet, 
  TrendingUp,
  Pill,
  Sparkles,
  Home,
  BarChart3,
  Bell,
  User,
  History,
  ChevronRight
} from 'lucide-react-native';

export default function Dashboard() {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.logo}>
            <TrendingUp size={24} color="#fff" />
          </View>
          <Text style={styles.logoText}>Liverlytics</Text>
        </View>
        <View style={styles.headerRight}>
          <View style={styles.premiumBadge}>
            <Sparkles size={14} color="#666" />
            <Text style={styles.premiumText}>Premium</Text>
          </View>
          <View style={styles.avatar}>
            <User size={20} color="#666" />
          </View>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Title */}
        <Text style={styles.title}>Good Morning — Here's your health summary.</Text>
        <Text style={styles.subtitle}>Data shown is a snapshot. Tap any card to view details.</Text>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <TestTube size={20} color="#fff" />
            </View>
            <Text style={styles.actionLabel}>Add{'\n'}Lab Data</Text>
            <Text style={styles.actionSubtext}>MELD inputs</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Utensils size={20} color="#fff" />
            </View>
            <Text style={styles.actionLabel}>Add{'\n'}Diet Entry</Text>
            <Text style={styles.actionSubtext}>Sodium &{'\n'}intake</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <FileText size={20} color="#fff" />
            </View>
            <Text style={styles.actionLabel}>Add{'\n'}Notes</Text>
            <Text style={styles.actionSubtext}>Symptoms &{'\n'}reminders</Text>
          </TouchableOpacity>
        </View>

        {/* Flags Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Flag size={20} color="#333" />
              <Text style={styles.sectionTitleText}>Flags</Text>
            </View>
            <Text style={styles.sectionBadge}>Attention</Text>
          </View>

          <View style={styles.flagCard}>
            <Text style={styles.flagText}>Missed evening medication yesterday.</Text>
          </View>
          <View style={styles.flagCard}>
            <Text style={styles.flagText}>BP trending near upper range.</Text>
          </View>
        </View>

        {/* Vitals Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Activity size={20} color="#333" />
              <Text style={styles.sectionTitleText}>Vitals</Text>
            </View>
            <Text style={styles.sectionTime}>Today</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.vitalRow}>
              <View style={styles.vitalItem}>
                <Text style={styles.vitalLabel}>BP:</Text>
                <Text style={styles.vitalValue}>120/80</Text>
              </View>
              <View style={styles.vitalItem}>
                <Text style={styles.vitalLabel}>Glucose:</Text>
                <Text style={styles.vitalValue}>98 mg/dL</Text>
              </View>
            </View>
            <View style={styles.vitalRow}>
              <View style={styles.vitalItem}>
                <Text style={styles.vitalLabel}>Weight:</Text>
                <Text style={styles.vitalValue}>72 kg</Text>
              </View>
            </View>
            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.addButton}>
                <Plus size={16} color="#fff" />
                <Text style={styles.addButtonText}>Add / Update</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.historyButton}>
                <History size={16} color="#666" />
                <Text style={styles.historyButtonText}>Vitals History</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* MELD Score Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Scale size={20} color="#333" />
              <Text style={styles.sectionTitleText}>MELD Score</Text>
            </View>
            <Text style={styles.meldScore}>Latest: 12</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.updateText}>Last updated 2d ago</Text>
            <View style={styles.meldTags}>
              <View style={styles.tag}>
                <Text style={styles.tagText}>Bilirubin</Text>
              </View>
              <View style={styles.tag}>
                <Text style={styles.tagText}>INR</Text>
              </View>
              <View style={styles.tag}>
                <Text style={styles.tagText}>Creatinine</Text>
              </View>
            </View>
            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.addButton}>
                <Plus size={16} color="#fff" />
                <Text style={styles.addButtonText}>Add / Update</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.historyButton}>
                <History size={16} color="#666" />
                <Text style={styles.historyButtonText}>MELD History</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Diet & Fluids Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Droplet size={20} color="#333" />
              <Text style={styles.sectionTitleText}>Diet & Fluids</Text>
            </View>
            <Text style={styles.sectionTime}>Today</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.dietRow}>
              <Text style={styles.dietLabel}>Sodium: <Text style={styles.dietValue}>1.7 g</Text></Text>
              <Text style={styles.dietLabel}>Fluids: <Text style={styles.dietValue}>1.2 L</Text></Text>
            </View>
          </View>
        </View>

        {/* Exercise Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Heart size={20} color="#333" />
              <Text style={styles.sectionTitleText}>Exercise</Text>
            </View>
            <Text style={styles.sectionTime}>Today</Text>
          </View>

          <View style={styles.card}>
            <View style={styles.exerciseRow}>
              <Text style={styles.exerciseLabel}>Steps: <Text style={styles.exerciseValue}>6,420</Text></Text>
              <Text style={styles.exerciseLabel}>Rest HR: <Text style={styles.exerciseValue}>62 bpm</Text></Text>
            </View>
            <View style={styles.exerciseRow}>
              <Text style={styles.exerciseLabel}>Sleep: <Text style={styles.exerciseValue}>410 min</Text></Text>
            </View>
            <View style={styles.cardActions}>
              <TouchableOpacity style={styles.addButton}>
                <Plus size={16} color="#fff" />
                <Text style={styles.addButtonText}>Add / Update</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.historyButton}>
                <History size={16} color="#666" />
                <Text style={styles.historyButtonText}>Exercise History</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Medications Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Pill size={20} color="#333" />
              <Text style={styles.sectionTitleText}>Medications</Text>
            </View>
            <Text style={styles.sectionTime}>This week</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.adherenceText}>Adherence: 86%</Text>
            <TouchableOpacity style={styles.addMedicineButton}>
              <Plus size={16} color="#fff" />
              <Text style={styles.addButtonText}>Add Medicine</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* AI Insights Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitle}>
              <Sparkles size={20} color="#333" />
              <Text style={styles.sectionTitleText}>AI Insights</Text>
            </View>
            <Text style={styles.sectionTime}>Updated today</Text>
          </View>

          <View style={styles.insightCard}>
            <Text style={styles.insightText}>
              Your BP is trending slightly high this week. Consider a light walk after dinner and reduce sodium intake.
            </Text>
          </View>
        </View>

        {/* Today's Summary */}
        <View style={styles.section}>
          <Text style={styles.summaryTitle}>Today's Summary</Text>
          <View style={styles.summaryGrid}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Sodium:</Text>
              <Text style={styles.summaryValue}>1800 mg</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Fluids:</Text>
              <Text style={styles.summaryValue}>1600 mL</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Steps:</Text>
              <Text style={styles.summaryValue}>5200</Text>
            </View>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>HR:</Text>
            <Text style={styles.summaryValue}>62 bpm resting</Text>
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem}>
          <Home size={24} color="#4CAF50" />
          <Text style={[styles.navText, styles.navTextActive]}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <BarChart3 size={24} color="#999" />
          <Text style={styles.navText}>Reports</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <Bell size={24} color="#999" />
          <Text style={styles.navText}>Reminders</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <User size={24} color="#999" />
          <Text style={styles.navText}>Profile</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 8,
    color: '#333',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: '#F0F0F0',
    borderRadius: 12,
  },
  premiumText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 20,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  actionCard: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
    marginBottom: 4,
  },
  actionSubtext: {
    fontSize: 11,
    color: '#666',
    textAlign: 'center',
  },
  section: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sectionTitleText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  sectionBadge: {
    fontSize: 12,
    color: '#FF9800',
    fontWeight: '600',
  },
  sectionTime: {
    fontSize: 12,
    color: '#666',
  },
  meldScore: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  flagCard: {
    backgroundColor: '#FFF9C4',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  flagText: {
    fontSize: 14,
    color: '#333',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  vitalRow: {
    flexDirection: 'row',
    gap: 24,
    marginBottom: 12,
  },
  vitalItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  vitalLabel: {
    fontSize: 14,
    color: '#666',
  },
  vitalValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    backgroundColor: '#F0F0F0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  cardActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  addButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  historyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
  },
  historyButtonText: {
    color: '#666',
    fontSize: 14,
  },
  updateText: {
    fontSize: 12,
    color: '#666',
    marginBottom: 12,
  },
  meldTags: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  tag: {
    backgroundColor: '#F0F0F0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  tagText: {
    fontSize: 12,
    color: '#666',
  },
  dietRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  dietLabel: {
    fontSize: 14,
    color: '#666',
  },
  dietValue: {
    fontWeight: '600',
    color: '#333',
  },
  exerciseRow: {
    flexDirection: 'row',
    gap: 24,
    marginBottom: 8,
  },
  exerciseLabel: {
    fontSize: 14,
    color: '#666',
  },
  exerciseValue: {
    fontWeight: '600',
    color: '#333',
  },
  adherenceText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  addMedicineButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 10,
  },
  insightCard: {
    backgroundColor: '#00897B',
    borderRadius: 12,
    padding: 16,
  },
  insightText: {
    fontSize: 14,
    color: '#fff',
    lineHeight: 20,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  summaryGrid: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 12,
  },
  summaryItem: {
    flex: 1,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#666',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingVertical: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 4,
  },
  navText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  navTextActive: {
    color: '#4CAF50',
    fontWeight: '600',
  },
});