
// src/screens/LabReportDetailsScreen.tsx
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const LabReportDetailsScreen = ({ navigation }) => {
  const labs = [
    { name: 'Bilirubin', value: '1.8 mg/dL', range: '0.1-1.2', flag: 'High', flagColor: '#ef4444' },
    { name: 'INR', value: '1.5', range: '0.9-1.2', flag: 'Mild', flagColor: '#f59e0b' },
    { name: 'Creatinine', value: '0.9 mg/dL', range: '0.7-1.3', flag: 'Normal', flagColor: '#52a64a' },
    { name: 'Sodium', value: '132 mmol/L', range: '135-145', flag: 'Low', flagColor: '#f59e0b' },
    { name: 'Albumin', value: '3.1 g/dL', range: '3.5-5.0', flag: 'Low', flagColor: '#f59e0b' },
    { name: 'AST', value: '58 U/L', range: '10-40', flag: 'High', flagColor: '#ef4444' },
    { name: 'ALT', value: '72 U/L', range: '7-56', flag: 'High', flagColor: '#ef4444' },
    { name: 'Platelet Count', value: '130 ×10^9/L', range: '150-400', flag: 'Low', flagColor: '#f59e0b' },
    { name: 'Hemoglobin', value: '12.9 g/dL', range: '13.5-17.5', flag: 'Low', flagColor: '#f59e0b' },
    { name: 'WBC', value: '5.6 ×10^9/L', range: '4.0-11.0', flag: 'Normal', flagColor: '#52a64a' },
    { name: 'Potassium', value: '4.2 mmol/L', range: '3.5-5.1', flag: 'Normal', flagColor: '#52a64a' },
    { name: 'Ammonia', value: '42 μmol/L', range: '15-45', flag: 'Normal', flagColor: '#52a64a' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <View style={styles.logo}>
              <Icon name="trending-up" size={24} color="#fff" />
            </View>
            <Text style={styles.logoText}>Liverlytics</Text>
          </View>
        </View>

        <View style={styles.titleSection}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color="#1f2937" />
          </TouchableOpacity>
          <Text style={styles.title}>Reports</Text>
        </View>

        <View style={styles.content}>
          {/* Report Metadata */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Report Metadata</Text>

            <View style={styles.metaRow}>
              <Icon name="calendar-outline" size={18} color="#6b7280" />
              <Text style={styles.metaLabel}>Uploaded: May 11, 2025 • 09:15</Text>
              <View style={styles.pdfBadge}>
                <Text style={styles.pdfText}>PDF</Text>
              </View>
            </View>

            <View style={styles.metaRow}>
              <Icon name="sparkles-outline" size={18} color="#6b7280" />
              <Text style={styles.metaLabel}>Parsing confidence</Text>
              <View style={styles.confidenceBadge}>
                <Text style={styles.confidenceText}>93%</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.downloadButton}>
              <Icon name="download-outline" size={18} color="#1f2937" />
              <Text style={styles.downloadText}>Download Parsed PDF</Text>
            </TouchableOpacity>
          </View>

          {/* Extracted Labs */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Extracted Labs</Text>

            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={[styles.tableHeaderText, { flex: 2 }]}>Parameter</Text>
                <Text style={[styles.tableHeaderText, { flex: 2 }]}>Extracted Value</Text>
                <Text style={[styles.tableHeaderText, { flex: 2 }]}>Normal Range</Text>
                <Text style={[styles.tableHeaderText, { flex: 1 }]}>Flag</Text>
              </View>

              {labs.map((lab, index) => (
                <View key={index} style={styles.tableRow}>
                  <Text style={[styles.tableCell, { flex: 2 }]}>{lab.name}</Text>
                  <Text style={[styles.tableCell, { flex: 2 }]}>{lab.value}</Text>
                  <Text style={[styles.tableCell, { flex: 2 }]}>{lab.range}</Text>
                  <View style={[styles.tableCell, { flex: 1 }]}>
                    <View style={[styles.flagBadge, { backgroundColor: lab.flagColor }]}>
                      <Text style={styles.flagText}>{lab.flag}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Insights */}
          <View style={styles.insightsCard}>
            <Text style={styles.insightsTitle}>Insights</Text>
            <View style={styles.insightItem}>
              <Icon name="analytics-outline" size={16} color="#fff" />
              <Text style={styles.insightText}>Sodium slightly lower than previous reading.</Text>
            </View>
            <View style={styles.insightItem}>
              <Icon name="trending-up-outline" size={16} color="#fff" />
              <Text style={styles.insightText}>ALT increased compared to last report.</Text>
            </View>
          </View>

          {/* Related MELD Values */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Related MELD Values</Text>
            <View style={styles.meldRow}>
              <View style={styles.meldLeft}>
                <Icon name="pulse-outline" size={20} color="#374151" />
                <View>
                  <Text style={styles.meldLabel}>MELD-Na: 18</Text>
                  <Text style={styles.meldSubtext}>MELD 3.0: 20</Text>
                  <Text style={styles.meldTime}>Timestamp: May 11, 2025 • 09:16</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.viewMeldButton}>
                <Text style={styles.viewMeldText}>View Full MELD History</Text>
                <Icon name="chevron-forward" size={16} color="#52a64a" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 40,
    height: 40,
    backgroundColor: '#52a64a',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  logoText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1f2937',
  },
  titleSection: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    gap: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1f2937',
  },
  content: {
    padding: 16,
  },
  card: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 16,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    gap: 10,
  },
  metaLabel: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
  },
  pdfBadge: {
    backgroundColor: '#f3f4f6',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  pdfText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#374151',
  },
  confidenceBadge: {
    backgroundColor: '#d1fae5',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  confidenceText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#16a34a',
  },
  downloadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    gap: 8,
  },
  downloadText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1f2937',
  },
  table: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f9fafb',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  tableHeaderText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  tableCell: {
    fontSize: 13,
    color: '#374151',
  },
  flagBadge: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  flagText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#fff',
  },
  insightsCard: {
    backgroundColor: '#0d9488',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  insightsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 12,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
    gap: 8,
  },
  insightText: {
    flex: 1,
    fontSize: 14,
    color: '#fff',
    lineHeight: 20,
  },
  meldRow: {
    gap: 12,
  },
  meldLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  meldLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  meldSubtext: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 4,
  },
  meldTime: {
    fontSize: 12,
    color: '#9ca3af',
  },
  viewMeldButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0fdf4',
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#86efac',
    gap: 6,
  },
  viewMeldText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#52a64a',
  },
});

export default LabReportDetailsScreen;