// src/screens/RemindersAlertsScreen.tsx
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  SafeAreaView,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const RemindersAlertsScreen = ({ navigation }) => {
  const alerts = [
    {
      icon: 'trending-up',
      title: 'Xgth rising faster than usual',
      subtitle: 'Xgth up by 1.8 kg against recent data',
      time: 'Today',
      source: 'Vitals',
      badge: 'Medium',
      badgeColor: '#f59e0b',
    },
    {
      icon: 'alert-circle',
      title: 'Rapid weight gain detected over 48 hours',
      subtitle: '+ 3 kg in baseline over last 2 days',
      time: '18:45',
      source: 'Vitals',
      badge: 'High',
      badgeColor: '#ef4444',
    },
    {
      icon: 'restaurant',
      title: 'Daily sodium target exceeded',
      subtitle: '2,350 mg logged versus modular',
      time: 'Yesterday',
      source: 'Diet',
      badge: 'Medium',
      badgeColor: '#f59e0b',
    },
    {
      icon: 'heart',
      title: 'Elevated resting heart rate compared to baseline',
      subtitle: 'Resting HR 80 bpm vs baseline 68 bpm',
      time: 'Today',
      source: 'Vitals',
      badge: 'Medium',
      badgeColor: '#f59e0b',
    },
  ];

  const reminders = [
    { label: 'Daily weight check', time: '08:30', active: true },
    { label: 'Sodium limit reminder', time: '21:00', active: true },
    { label: 'Fluid intake reminders', time: 'Throughout day', active: true },
    { label: 'Manual vitals check', time: '09:30', active: false },
    { label: 'Exercise reminder (walk / light activity)', time: '17:00', active: true },
    { label: 'Medication dose reminders', time: 'Multiple times', active: true },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <View style={styles.logo}>
              <Icon name="trending-up" size={24} color="#fff" />
            </View>
            <Text style={styles.logoText}>Liverlytics</Text>
          </View>
        </View>

        <View style={styles.titleSection}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color="#1f2937" />
          </TouchableOpacity>
          <Text style={styles.title}>Reminders & Alerts</Text>
        </View>

        <View style={styles.content}>
          {/* Active Alerts & Flags */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Active Alerts & Flags</Text>
            <Text style={styles.sectionSubtitle}>
              AI detections for changes, trends, and medication events.
            </Text>

            {alerts.map((alert, index) => (
              <View key={index} style={styles.alertCard}>
                <View style={styles.alertHeader}>
                  <Icon name={alert.icon} size={20} color="#374151" />
                  <View style={styles.alertInfo}>
                    <Text style={styles.alertTitle}>{alert.title}</Text>
                    <Text style={styles.alertSubtitle}>{alert.subtitle}</Text>
                  </View>
                </View>
                <View style={styles.alertFooter}>
                  <View style={styles.alertMeta}>
                    <Icon name="pulse-outline" size={14} color="#6b7280" />
                    <Text style={styles.alertSource}>Source: {alert.source}</Text>
                  </View>
                  <View style={[styles.alertBadge, { backgroundColor: alert.badgeColor }]}>
                    <Text style={styles.alertBadgeText}>{alert.badge}</Text>
                  </View>
                </View>
              </View>
            ))}

            <Text style={styles.disclaimer}>
              All AI programs are informational and are not diagnostic.{'\n'}
              AI results 1.0 on device-owned Xorg set to 10.
            </Text>
          </View>

          {/* Your Reminders */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Your Reminders</Text>
            <Text style={styles.sectionSubtitle}>Daily alerts and dose reminders you control.</Text>

            {reminders.map((reminder, index) => (
              <View key={index} style={styles.reminderRow}>
                <View style={styles.reminderInfo}>
                  <Text style={styles.reminderLabel}>{reminder.label}</Text>
                  <Text style={styles.reminderTime}>{reminder.time}</Text>
                </View>
                <View style={styles.reminderRight}>
                  {reminder.badge && (
                    <View style={styles.reminderBadge}>
                      <Text style={styles.reminderBadgeText}>Overdue</Text>
                    </View>
                  )}
                  <Switch
                    value={reminder.active}
                    trackColor={{ false: '#d1d5db', true: '#86efac' }}
                    thumbColor={reminder.active ? '#52a64a' : '#f3f4f6'}
                  />
                </View>
              </View>
            ))}
          </View>

          {/* Action Buttons */}
          <TouchableOpacity style={styles.manageButton}>
            <Icon name="settings-outline" size={20} color="#fff" />
            <Text style={styles.manageButtonText}>Manage Reminders</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.adjustButton}>
            <Icon name="options-outline" size={20} color="#52a64a" />
            <Text style={styles.adjustButtonText}>Adjust Alert Thresholds in Settings</Text>
          </TouchableOpacity>

          <Text style={styles.configNote}>
            Configure weight targets, sodium targets, testing the config features for
            tracking & MRA-based thresholds, salt uses and custom X-axis grid targets &
            to set parameters.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 40,
    height: 40,
    backgroundColor: '#52a64a',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  logoText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1f2937',
  },
  titleSection: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    gap: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1f2937',
  },
  content: {
    padding: 16,
  },
  section: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: '#6b7280',
    marginBottom: 16,
    lineHeight: 18,
  },
  alertCard: {
    backgroundColor: '#f9fafb',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
    gap: 10,
  },
  alertInfo: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  alertSubtitle: {
    fontSize: 13,
    color: '#6b7280',
    lineHeight: 18,
  },
  alertFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  alertMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  alertSource: {
    fontSize: 12,
    color: '#6b7280',
  },
  alertBadge: {
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 12,
  },
  alertBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#fff',
  },
  disclaimer: {
    fontSize: 11,
    color: '#9ca3af',
    marginTop: 8,
    lineHeight: 16,
    textAlign: 'center',
  },
  reminderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  reminderInfo: {
    flex: 1,
  },
  reminderLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1f2937',
    marginBottom: 4,
  },
  reminderTime: {
    fontSize: 12,
    color: '#6b7280',
  },
  reminderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  reminderBadge: {
    backgroundColor: '#f59e0b',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 10,
  },
  reminderBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#fff',
  },
  manageButton: {
    flexDirection: 'row',
    backgroundColor: '#52a64a',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    gap: 8,
  },
  manageButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  adjustButton: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#52a64a',
    marginBottom: 12,
    gap: 8,
  },
  adjustButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#52a64a',
  },
  configNote: {
    fontSize: 11,
    color: '#9ca3af',
    textAlign: 'center',
    lineHeight: 16,
  },
});

export default RemindersAlertsScreen;