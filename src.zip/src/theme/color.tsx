import React from "react";


export const PRIMARY_COLOR = '#52ab3c';
export const SECONDARY_COLOR = '#00FF00';
export const TERTIARY_COLOR = '#0000FF';
export const LightgrayColor = '#E6E9EB';
export const White = '#fff';
export const CoolGray = '#93A0A8';
export const Navyblue = '#0F2740';
export const BlueishGray = '#4A5568'

